/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package programmingassignment;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author lab_services_student
 */
public class ProgrammingAssignmentTest {
    
       private ArrayList<Student> studs;
    private Student studentManager;

    @Before
    public void setUp() {
        studs = new ArrayList<>();
        studentManager = new Student();
    }

    @Test
    public void TestSaveStudent() {
        // Test saving a student
        studentManager.saveStudent(studs, new Scanner("1\n1\nJohn\n18\njohn@example.com\nMath"));
        assertEquals(1, studs.size());
        assertEquals("John", studs.get(0).name);
    }

    @Test
    public void TestSearchStudent() {
        // Test searching for an existing student
        Student newStudent = new Student(1, "John", 18, "john@example.com", "Math");
        studs.add(newStudent);
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        studentManager.searchStudent(studs, 1);
        assertTrue(outContent.toString().contains("John"));
    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        // Test searching for a non-existent student
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        studentManager.searchStudent(studs, 2);
        assertTrue(outContent.toString().contains("STUDENT WITH STUDENT ID 2 WAS NOT FOUND"));
    }

    @Test
    public void TestDeleteStudent() {
        // Test deleting an existing student
        Student newStudent = new Student(1, "John", 18, "john@example.com", "Math");
        studs.add(newStudent);
        studentManager.deleteStudent(studs, 1);
        assertEquals(0, studs.size());
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        // Test deleting a non-existent student
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        studentManager.deleteStudent(studs, 2);
        assertTrue(outContent.toString().contains("Student id not found"));
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Test supplying a valid student age
        assertTrue(studentManager.isAgeValid(18));
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        // Test supplying an invalid student age (less than 16)
        assertFalse(studentManager.isAgeValid(15));
    }

    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Test supplying an invalid character as student age
        assertFalse(studentManager.isAgeValid(16));
    }
}