/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programmingassignment;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class ProgrammingAssignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*******************************");

        Scanner sc = new Scanner(System.in);
        ArrayList<Student> studs = new ArrayList<>();

        Student studentManager = new Student();

        while (true) {
            System.out.println("Please select one of the following menu items: ");
            System.out.println("(1) Capture a new student.");
            System.out.println("(2) Search for a student.");
            System.out.println("(3) Delete a student.");
            System.out.println("(4) Print student report.");
            System.out.println("(5) Exit Application ");
            System.out.print("Enter your option: ");
            int option = sc.nextInt();
            System.out.println("");

            if (option == 1) {
                System.out.println("CAPTURE A NEW STUDENT");
                System.out.println("***************************************");

                studentManager.saveStudent(studs, sc);

            } else if (option == 2) {
                System.out.println("ENTER THE STUDENT ID TO SEARCH: ");
                int id = sc.nextInt();
                boolean found = false;

                studentManager.searchStudent(studs, id);

            } else if (option == 3) {
                System.out.println("ENTER STUDENT ID TO DELETE: ");
                int id = sc.nextInt();

                studentManager.deleteStudent(studs, id);
            } else if (option == 4) {
                System.out.println("******************************************");

                studentManager.studentReport(studs);
               
            } else if (option == 5) {
                System.out.println("\nClosing Application");
                studentManager.exitStudentApplication();
                break;
            }
            System.out.println("");
        }
        sc.close();
    }
   
   
   
}

class Student{ 
     int id;
    String name;
    int age;
    String email;
    String course;

    public void saveStudent(ArrayList<Student> studs, Scanner sc) {
        System.out.print("ENTER THE STUDENT ID: ");
        id = sc.nextInt();
        System.out.print("ENTER THE STUDENT NAME: ");
        name = sc.next();
        int age;
        do {
            System.out.print("ENTER THE STUDENT AGE: ");
            age = sc.nextInt();
            if (age < 16) {
                System.out.println("YOU HAVE ENTERED AN INCORRECT STUDENT AGE!");
            }
        } while (age < 16);
        System.out.print("ENTER THE STUDENT EMAIL: ");
        email = sc.next();
        System.out.print("ENTER THE STUDENT COURSE: ");
        course = sc.next();

        Student newStud = new Student(id, name, age, email, course);
        studs.add(newStud);
        System.out.println("Student details have been successfully saved.");
    }

    public void searchStudent(ArrayList<Student> studs, int id) {
        boolean found = false;
        for (Student student : studs) {
            if (student.id == id) {
                System.out.println("******************************************");
                System.out.println("STUDENT ID: " + student.id);
                System.out.println("STUDENT NAME: " + student.name);
                System.out.println("STUDENT AGE: " + student.age);
                System.out.println("STUDENT EMAIL: " + student.email);
                System.out.println("STUDENT COURSE: " + student.course);
                System.out.println("******************************************");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("******************************************");
            System.out.println("STUDENT WITH STUDENT ID " + id + " WAS NOT FOUND");
            System.out.println("******************************************");
        }
    }

    public void deleteStudent(ArrayList<Student> studs, int id) {
        boolean found = false;
        for (Student student : studs) {
            if (student.id == id) {
                found = true;
                studs.remove(student);
                System.out.println("******************************************");
                System.out.println("STUDENT WITH STUDENT ID " + id + " WAS DELETED");
                System.out.println("******************************************");
                break;
            }
        }
        if (!found) {
            System.out.println("Student id not found");
        }
    }

    public void studentReport(ArrayList<Student> studs) {
        System.out.println("******************************************");
        for (Student student : studs) {
            System.out.println("STUDENT " + student.id);
            System.out.println("******************************************");
            System.out.println("STUDENT ID: " + student.id);
            System.out.println("STUDENT NAME: " + student.name);
            System.out.println("STUDENT AGE: " + student.age);
            System.out.println("STUDENT EMAIL: " + student.email);
            System.out.println("STUDENT COURSE: " + student.course);
        }
        System.out.println("******************************************");
    }

    public void exitStudentApplication() {
       
    }

    public Student() {
        // Default constructor
    }

    public Student(int id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    @Override
    public String toString() {
        return "Student : " + "\n\tid=" + id + "\n\tname=" + name + "\n\tage=" + age + "\n\temail=" + email +
                "\n\tcourse=" + course;
    }

    boolean isAgeValid(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}



    





   
    
    

